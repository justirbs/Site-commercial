<?php
  session_start();
?>

<html>

<head>
    <title>Kukulkan | Cigarettes</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta charset="utf-8">
    <link rel="icon" type="image/jpg" href="../img/kulkulkan.jpg">
    <link rel="stylesheet" type="text/css" href="../css/style.css" />
</head>

<body>

    <?php
      require("index.php");
    ?>

    <!-- le header de la page -->
    <div class="header">
        <div class="topnav">
            <img src="../img/kulkulkan.jpg" alt="logo" />
            <a href="../index.html">Société Kukulkan</a>
            <a href="./cigarettes.html" class="active">Cigarettes</a>
            <a href="./gouts.html">Goûts</a>
            <a href="./accessoires.html">Accessoires</a>
            <a href="./contact.html">Contact</a>
            <a href="" style="float:right" class="active">Connexion</a>
        </div>
    </div>

    <!-- le corps de la page -->
    <div class="corps">

        <!-- le menu à gauche de la page -->
        <div class="menu">
            <h3>Site Kukulkan</h3>
            <a href="../index.html">Accueil</a>
            <h3>Nos produits</h3>
            <a href="./cigarettes.html">Cigarettes</a><br/><br/>
            <a href="./gouts.html">Goûts</a><br/><br/>
            <a href="./accessoires.html">Accessoires</a><br/>
            <h3>Contactez nous</h3>
            <a href="./contact.html">Contact</a>
        </div>

        <!-- le contenu principal à droite de la page -->
        <div class="principal">
            <h2>Nos cigarettes</h2>
            <table id="tabCigarette">
                <tr>
                    <th>Photo</th>
                    <th>Référence</th>
                    <th>Description</th>
                    <th>Prix</th>
                    <th>Commandes</th>
                </tr>
                <tr>
                    <td><img src="../img/e-box.jpeg" alt="Inti ecig-box" onclick="zoomer(this)"/></td>
                    <td>11888</td>
                    <td>Inti est une e-cig box permettant de faire de gros nuages de fumés. Elle a une autonomie de 2 jours et sera apprecier des vapoteur expérimenté</td>
                    <td>62€90</td>
                    <td>
                        <div class="divCommande" id="commande_0">
                            <input type="button" class="button" value="-" onclick="diminuer(this)"> 
                            <p>0</p> 
                            <input type="button" class="button" value="+" onclick="augmenter(this)">
                        </div>
                        <input type="button" class="buttonPanier" value="Ajouter au panier" onclick="">
                    </td>
                </tr>
                <tr>
                    <td><img src="../img/e-tube.jpg" alt="Quetzali ecig-tube" onclick="zoomer(this)"/></td>
                    <td>11775</td>
                    <td>Izel est une e-cig tube permettant de faire beaucoup de fumée. La batterie tient un peu moins de 2 jours. </td>
                    <td>41€90</td>
                    <td>
                        <div class="divCommande" id="commande_1">
                            <input type="button" class="button" value="-" onclick="diminuer(this)"> 
                            <p>0</p> 
                            <input type="button" class="button" value="+" onclick="augmenter(this)">
                        </div>
                        <input type="button" class="buttonPanier" value="Ajouter au panier" onclick="">
                    </td>
                </tr>
                <tr>
                    <td><img src="../img/e-pod.png" alt="Izel ecig-pod" onclick="zoomer(this)"/></td>
                    <td>11005</td>
                    <td>Quetzali est une e-cig pod dont la forme se rapproche de celle d'une cigarette. Elle a une autonomie d'une journée</td>
                    <td>23€90</td>
                    <td>
                        <div class="divCommande" id="commande_2">
                            <input type="button" class="button" value="-" onclick="diminuer(this)"> 
                            <p>0</p> 
                            <input type="button" class="button" value="+" onclick="augmenter(this)">
                        </div>
                        <input type="button" class="buttonPanier" value="Ajouter au panier" onclick="">
                    </td>
                </tr>
                <tr>
                    <td><img src="../img/e-jetable.jpg" alt="ecig-jetable" onclick="zoomer(this)"/></td>
                    <td>11666</td>
                    <td>Ikal est une cigarette electronique jetable. Son usage est réservé aux fumeurs qui souhaitent arrêter la cigarette. </td>
                    <td>9€90</td>
                    <td>
                        <div class="divCommande" id="commande_3">
                            <input type="button" class="button" value="-" onclick="diminuer(this)"> 
                            <p>0</p> 
                            <input type="button" class="button" value="+" onclick="augmenter(this)">
                        </div>
                        <input type="button" class="buttonPanier" value="Ajouter au panier" onclick="">
                    </td>
                </tr>
                <tr>
                    <td><img src="../img/e-cigalike.png" alt="e-cigalike" onclick="zoomer(this)"/></td>
                    <td>11100</td>
                    <td>Tooko est un paquet de e-cigalike, l'ancêtre de la cigarette electronique. Cette version 2.0 vous permettra de retrouver toutes les habitudes d'un vrai fumeur comme le gest ou le paquet de cigarette (ici la batterie). </td>
                    <td>35€</td>
                    <td>
                        <div class="divCommande" id="commande_4">
                            <input type="button" class="button" value="-" onclick="diminuer(this)"> 
                            <p>0</p> 
                            <input type="button" class="button" value="+" onclick="augmenter(this)">
                        </div>
                        <input type="button" class="buttonPanier" value="Ajouter au panier" onclick="">
                    </td>
                </tr>
            </table>

            <div style="text-align:right; margin-top: 20px;" id="divBouton">
                <input type="button" class="button" id="boutonStock" value="Afficher les stocks" onclick="afficherStocks('tabCigarette')">
            </div>
        </div>
    </div>

    <!-- le footer de la page -->
    <div class="footer">
        <p>Pour nous contacter, veuillez composer le 05.59.01.02.03</p>
        <p>Copyright © 2022 Kukulkan</p>
    </div>

</body>

<script type="text/javascript" src="../js/stock.js"></script>
<script type="text/javascript" src="../js/image.js"></script>

</html>