<?php
  session_start();
?>

<html>

<head>
    <title> Kukulkan | Goûts</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta charset="utf-8">
    <link rel="icon" type="image/jpg" href="../img/kulkulkan.jpg">
    <link rel="stylesheet" type="text/css" href="../css/style.css" />
</head>

<body>

    <?php
      require("index.php");
    ?>

    <!-- le header de la page -->
    <div class="header">
        <div class="topnav">
            <img src="../img/kulkulkan.jpg" alt="logo" />
            <a href="../index.html">Société Kukulkan</a>
            <a href="./cigarettes.html">Cigarettes</a>
            <a href="./gouts.html" class="active">Goûts</a>
            <a href="./accessoires.html">Accessoires</a>
            <a href="./contact.html">Contact</a>
            <a href="" style="float:right" class="active">Connexion</a>
        </div>
    </div>

    <!-- le corps de la page -->
    <div class="corps">

        <!-- le menu à gauche de la page -->
        <div class="menu">
            <h3>Site Kukulkan</h3>
            <a href="../index.html">Accueil</a>
            <h3>Nos produits</h3>
            <a href="./cigarettes.html">Cigarettes</a><br/><br/>
            <a href="./gouts.html">Goûts</a><br/><br/>
            <a href="./accessoires.html">Accessoires</a><br/>
            <h3>Contactez nous</h3>
            <a href="./contact.html">Contact</a>
        </div>

        <!-- le contenu principal à droite de la page -->
        <div class="principal">
            <h2>Nos goûts</h2>
            <table id="tabGout">
                <tr>
                    <th>Photo</th>
                    <th>Référence</th>
                    <th>Description</th>
                    <th>Prix</th>
                    <th>Commandes</th>
                </tr>
                <tr>
                    <td><img src="../img/fruity-sun.png" alt="goût fraise pamplemousse" onclick="zoomer(this)"/></td>
                    <td>16978</td>
                    <td>Un duo méga fruité ! Retrouvez toute l’extravagance de la fraise et du pamplemousse dans ce mélange complétement fou à vaper sans modération !</td>
                    <td>18€90</td>
                    <td>
                        <div class="divCommande" id="commande_0">
                            <input type="button" class="button" value="-" onclick="diminuer(this)"> 
                            <p>0</p> 
                            <input type="button" class="button" value="+" onclick="augmenter(this)">
                        </div>
                        <input type="button" class="buttonPanier" value="Ajouter au panier" onclick="">
                    </td>
                </tr>
                <tr>
                    <td><img src="../img/kaplina.png" alt="goût borsalino la reserve" onclick="zoomer(this)"/></td>
                    <td>16821</td>
                    <td>Cette édition de notre Borsalino à steeper plus de 6 mois ce qui a pour effet de décupler les saveurs et d’offrir une divine rondeur en bouche..Les saveurs de notre Borsalino en version réserve Un mix corsé de tabac, caramel et cappuccino.</td>
                    <td>19€90</td>
                    <td>
                        <div class="divCommande" id="commande_1">
                            <input type="button" class="button" value="-" onclick="diminuer(this)"> 
                            <p>0</p> 
                            <input type="button" class="button" value="+" onclick="augmenter(this)">
                        </div>
                        <input type="button" class="buttonPanier" value="Ajouter au panier" onclick="">
                    </td>
                </tr>
                <tr>
                    <td><img src="../img/mousse.png" alt="goût mousse au chocolat blanc et noisette" onclick="zoomer(this)"/></td>
                    <td>16780</td>
                    <td>Laissez-vous tenter par cet eliquide terriblement savoureux ! Une mousse au chocolat blanc tout en légèreté saupoudré de fins éclats de noisette croquants.</td>
                    <td>19€90</td>
                    <td>
                        <div class="divCommande" id="commande_2">
                            <input type="button" class="button" value="-" onclick="diminuer(this)"> 
                            <p>0</p> 
                            <input type="button" class="button" value="+" onclick="augmenter(this)">
                        </div>
                        <input type="button" class="buttonPanier" value="Ajouter au panier" onclick="">
                    </td>
                </tr>
                <tr>
                    <td><img src="../img/ragnarok.png" alt="goût ragnarok" onclick="zoomer(this)"/></td>
                    <td>16759</td>
                    <td>Un mélange fruité aux saveurs de fruits rouges tel que des fraises et des mûres, des framboises et des myrtilles…</td>
                    <td>19€90</td>
                    <td>
                        <div class="divCommande" id="commande_3">
                            <input type="button" class="button" value="-" onclick="diminuer(this)"> 
                            <p>0</p> 
                            <input type="button" class="button" value="+" onclick="augmenter(this)">
                        </div>
                        <input type="button" class="buttonPanier" value="Ajouter au panier" onclick="">
                    </td>
                </tr>
                <tr>
                    <td><img src="../img/ananas.png" alt="goût ananas flambée" onclick="zoomer(this)"/></td>
                    <td>16744</td>
                    <td>Un cocktail détonnant aux saveurs acidulées et exotiques d’ananas rôti, avec le caractère boisé du whisky et aux légères notes de coco.</td>
                    <td>18€90</td>
                    <td>
                        <div class="divCommande" id="commande_4">
                            <input type="button" class="button" value="-" onclick="diminuer(this)"> 
                            <p>0</p> 
                            <input type="button" class="button" value="+" onclick="augmenter(this)">
                        </div>
                        <input type="button" class="buttonPanier" value="Ajouter au panier" onclick="">
                    </td>
                </tr>
            </table>

            <div style="text-align:right; margin-top: 20px;" id="divBouton">
                <input type="button" class="button" id="boutonStock" value="Afficher les stocks" onclick="afficherStocks('tabGout')">
            </div>

        </div>
    </div>

    <!-- le footer de la page -->
    <div class="footer">
        <p>Pour nous contacter, veuillez composer le 05.59.01.02.03</p>
        <p>Copyright © 2022 Kukulkan</p>
    </div>

</body>

<script type="text/javascript" src="../js/stock.js"></script>
<script type="text/javascript" src="../js/image.js"></script>

</html>