<?php
  session_start();
?>

<html>

<?php
    require("index.php");
?>

<head>
    <title>Kukulkan | Cigarettes</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta charset="utf-8">
    <link rel="icon" type="image/jpg" href="../img/kulkulkan.jpg">
    <link rel="stylesheet" type="text/css" href="../css/style.css" />
</head>

<body style="background-color: #333;">

    <div id="divImage" style="text-align: center; margin: 30px;">

    </div>
    <div id="divBoutton" style="text-align:center">
        <input type="button" class="button" value="Fermer la fenêtre" onclick="fermer()">
    </div>

</body>

<script type="text/javascript" src="../js/zoom.js"></script>

</html>