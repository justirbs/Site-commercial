<?php
  session_start();
?>

<html>
<head>
    <title> Kukulkan | Accessoires</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta charset="utf-8">
    <link rel="icon" type="image/jpg" href="../img/kulkulkan.jpg">
    <link rel="stylesheet" type="text/css" href="../css/style.css" />
</head>

<body>

    <?php
      require("index.php");
    ?>

    <!-- le header de la page -->
    <div class="header">
        <div class="topnav">
            <img src="../img/kulkulkan.jpg" alt="logo" />
            <a href="../index.html">Société Kukulkan</a>
            <a href="./cigarettes.html">Cigarettes</a>
            <a href="./gouts.html">Goûts</a>
            <a href="./accessoires.html" class="active">Accessoires</a>
            <a href="./contact.html">Contact</a>
            <a href="" style="float:right" class="active">Connexion</a>
        </div>
    </div>

    <!-- le corps de la page -->
    <div class="corps">

        <!-- le menu à gauche de la page -->
        <div class="menu">
            <h3>Site Kukulkan</h3>
            <a href="../index.html">Accueil</a>
            <h3>Nos produits</h3>
            <a href="./cigarettes.html">Cigarettes</a><br/><br/>
            <a href="./gouts.html">Goûts</a><br/><br/>
            <a href="./accessoires.html">Accessoires</a><br/>
            <h3>Contactez nous</h3>
            <a href="./contact.html">Contact</a>
        </div>

        <!-- le contenu principal à droite de la page -->
        <div class="principal">
            <h2>Nos accesoires</h2>
            <table id="tabAccessoire">
                <tr>
                    <th>Photo</th>
                    <th>Référence</th>
                    <th>Description</th>
                    <th>Prix</th>
                    <th>Commandes</th>
                </tr>
                <tr>
                    <td><img src="../img/vapband.png" alt="Vapband" onclick="zoomer(this)"/></td>
                    <td>13704</td>
                    <td>Conçu pour protéger le Pyrex de votre Atomiseur , ce VapBand en silicone saura également le personnaliser, vous ne pourrez plus vous en passer !</td>
                    <td>0€90</td>
                    <td>
                        <div class="divCommande" id="commande_0">
                            <input type="button" class="button" value="-" onclick="diminuer(this)"> 
                            <p>0</p> 
                            <input type="button" class="button" value="+" onclick="augmenter(this)">
                        </div>
                        <input type="button" class="buttonPanier" value="Ajouter au panier" onclick="">
                    </td>
                </tr>
                <tr>
                    <td><img src="../img/charge.png" alt="chargeur USBC" onclick="zoomer(this)"/></td>
                    <td>16103</td>
                    <td>Le câble USB Type C 2.0 connecte votre cigarette électronique équipée de la nouvelle technologie USB-C, à tous ports USB pour une recharge efficace.</td>
                    <td>4€90</td>
                    <td>
                        <div class="divCommande" id="commande_1">
                            <input type="button" class="button" value="-" onclick="diminuer(this)"> 
                            <p>0</p> 
                            <input type="button" class="button" value="+" onclick="augmenter(this)">
                        </div>
                        <input type="button" class="buttonPanier" value="Ajouter au panier" onclick="">
                    </td>
                </tr>
                <tr>
                    <td><img src="../img/spray.png" alt="Spray nettoyant" onclick="zoomer(this)"/></td>
                    <td>12804</td>
                    <td>Le Spray Hydroalcoolique Multi-surfaces désinfecte immédiatement les mains et les surfaces, sans eau, sans savon et sans rinçage.</td>
                    <td>2€90</td>
                    <td>
                        <div class="divCommande" id="commande_2">
                            <input type="button" class="button" value="-" onclick="diminuer(this)"> 
                            <p>0</p> 
                            <input type="button" class="button" value="+" onclick="augmenter(this)">
                        </div>
                        <input type="button" class="buttonPanier" value="Ajouter au panier" onclick="">
                    </td>
                </tr>
                <tr>
                    <td><img src="../img/drip.png" alt="drip résine " onclick="zoomer(this)"/></td>
                    <td>12606</td>
                    <td>ces drips en résine vous feront lus ressentir les gouts que vous vapoter !</td>
                    <td>3€90</td>
                    <td>
                        <div class="divCommande" id="commande_3">
                            <input type="button" class="button" value="-" onclick="diminuer(this)"> 
                            <p>0</p> 
                            <input type="button" class="button" value="+" onclick="augmenter(this)">
                        </div>
                        <input type="button" class="buttonPanier" value="Ajouter au panier" onclick="">
                    </td>
                </tr>
                <tr>
                    <td><img src="../img/house.png" alt="" onclick="zoomer(this)"/></td>
                    <td>12841</td>
                    <td>Cette house en sillicon protegera votre cigarette electronique des chocs les plus violents pour une plus grande durabilité</td>
                    <td>4€90</td>
                    <td>
                        <div class="divCommande" id="commande_4">
                            <input type="button" class="button" value="-" onclick="diminuer(this)"> 
                            <p>0</p> 
                            <input type="button" class="button" value="+" onclick="augmenter(this)">
                        </div>
                        <input type="button" class="buttonPanier" value="Ajouter au panier" onclick="">
                    </td>
                </tr>
            </table>

            <div style="text-align:right; margin-top: 20px;" id="divBouton">
                <input type="button" class="button" id="boutonStock" value="Afficher les stocks" onclick="afficherStocks('tabAccessoire')">
            </div>

        </div>
    </div>

    <!-- le footer de la page -->
    <div class="footer">
        <p>Pour nous contacter, veuillez composer le 05.59.01.02.03</p>
        <p>Copyright © 2022 Kukulkan</p>
    </div>

</body>

<script type="text/javascript" src="../js/stock.js"></script>
<script type="text/javascript" src="../js/image.js"></script>

</html>