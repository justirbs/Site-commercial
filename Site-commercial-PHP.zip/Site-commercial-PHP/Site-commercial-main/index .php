<html>

<head>
    <title>Kulkan</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta charset="utf-8">
    <link rel="icon" type="image/jpg" href="./img/kulkulkan.jpg">
    <link rel="stylesheet" type="text/css" href="css/style.css" />
</head>

<body>

    <!-- le header de la page -->
    <div class="header">
        <div class="topnav">
            <img src="./img/kulkulkan.jpg" alt="logo" />
            <a href="./index.html" class="active">Société Kukulkan</a>
            <a href="./html/cigarettes.html">Cigarettes</a>
            <a href="./html/gouts.html">Goûts</a>
            <a href="./html/accessoires.html">Accessoires</a>
            <a href="./html/contact.html">Contact</a>
            <a href="" style="float:right" class="active">Connexion</a>
        </div>
    </div>

    <!-- le corps de la page -->
    <div class="corps">

        <!-- le menu à gauche de la page -->
        <div class="menu">
            <h3>Site Kukulkan</h3>
            <a href="./index.html">Accueil</a>
            <h3>Nos produits</h3>
            <a href="./html/cigarettes.html">Cigarettes</a><br/><br/>
            <a href="./html/gouts.html">Goûts</a><br/><br/>
            <a href="./html/accessoires.html">Accessoires</a><br/>
            <h3>Contactez nous</h3>
            <a href="./html/contact.html">Contact</a>
        </div>

        <!-- le contenu principal à droite de la page -->
        <div class="principal">
            <h1>"Fumez, tout en restant en bonne santé"</h1>
            <img src="./img/kulkulkan.jpg" alt="logo" style="width:400px;"/>
        </div>
    </div>

    <!-- le footer de la page -->
    <div class="footer">
        <p>Pour nous contacter, veuillez composer le 05.59.01.02.03</p>
        <p>Copyright © 2022 Kukulkan</p>
    </div>

</body>

</html>