# Développement Web - Site commercial

## Description 
Site pour un projet d'entrerise visant à commercialiser des cigratettes électroniques à l'apparence de cigarettes classiques dans le but de préserver la santé des consommateurs.

## Utilisation
Pour visualiser le site, il faut ouvrir le fichier "index.html" dans un navigateur web (de préférence chrome)
